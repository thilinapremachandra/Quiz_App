package com.example.myapplication1;

public class QuestionAnswer {
    public static String question[] = {
            "Which optimization algorithm is known for adjusting the learning rate during training based on the gradient's history?",
            "Which activation function is commonly used in the output layer for binary classification tasks?",
            "What is the primary advantage of using batch normalization in deep neural networks?",
            "What problem does the technique of 'dropout' aim to solve in deep learning?",
            "In which type of deep learning architecture would you typically find a 'long short-term memory' (LSTM) unit?",
            "Which layer in a convolutional neural network (CNN) is responsible for reducing the spatial dimensions of the input volume?",
            "Which technique involves reusing pre-trained models on tasks different from those they were originally trained on?",
            "Which loss function is commonly used for multi-class classification problems in deep learning?",
            "What does the term 'epoch' refer to in the context of training deep learning models?",
            "What is the purpose of the activation function in a neural network?"
    };
    public static String choices[][] = {
            {"Gradient Descent", "Adam", "RMSprop", "Stochastic Gradient Descent (SGD)"},
            {"ReLU", "Sigmoid", "Tanh", "Softmax"},
            {"It speeds up the training process.", "It prevents overfitting.", "It normalizes the inputs to each layer, reducing the risk of vanishing gradients.", "It improves the generalization of the model."},
            {"Overfitting", "Vanishing gradients", "Underfitting", "Oscillation in training"},
            {"Convolutional Neural Networks (CNNs)", "Recurrent Neural Networks (RNNs)", "Autoencoders", "Generative Adversarial Networks (GANs)"},
            {"Convolutional Layer", "Pooling Layer", "Fully Connected Layer", "Activation Layer"},
            {"Regularization", "Transfer Learning", "Data Augmentation", "Dropout"},
            {"Mean Squared Error (MSE)", "Cross-Entropy Loss", "Binary Cross-Entropy Loss", "Huber Loss"},
            {"The number of layers in the neural network", "The number of times the entire dataset is passed through the neural network during training", "The learning rate of the optimization algorithm", "The number of neurons in the output layer"},
            {"To introduce non-linearity", "To normalize the input data", "To reduce the dimensionality of the input", "To regularize the network"}
    };
    public static String correctAnswers[] = {"Adam", "Sigmoid", "It speeds up the training process.", "Overfitting", "Recurrent Neural Networks (RNNs)", "Pooling Layer", "Transfer Learning", "Cross-Entropy Loss", "The number of times the entire dataset is passed through the neural network during training", "To introduce non-linearity"};

}
