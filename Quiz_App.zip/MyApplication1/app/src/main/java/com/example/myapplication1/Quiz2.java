package com.example.myapplication1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Quiz2 extends AppCompatActivity implements View.OnClickListener {

    TextView totalQuestionsTextview;
    TextView questionsTextview;
    Button ansA;
    Button ansB;
    Button ansC;
    Button ansD;
    Button submitBtn;

    int score = 0;
    int totalQuestions = QuestionAnswer2.question.length;
    int currentQuestionIndex = 0;
    String selectedAnswer = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz2);

        totalQuestionsTextview = findViewById(R.id.totalQuestions);
        questionsTextview = findViewById(R.id.question);
        ansA = findViewById(R.id.ans_A);
        ansB = findViewById(R.id.ans_B);
        ansC = findViewById(R.id.ans_C);
        ansD = findViewById(R.id.ans_D);
        submitBtn = findViewById(R.id.submitButton);

        totalQuestionsTextview.setText("Total Questions :" + totalQuestions);

        loadNewQuestions();

        ansA.setOnClickListener(this);
        ansB.setOnClickListener(this);
        ansC.setOnClickListener(this);
        ansD.setOnClickListener(this);
        submitBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Button clickedButton = (Button) v;

        if (clickedButton.getId() == R.id.submitButton) {
            // Check if an answer is selected
            if (!selectedAnswer.isEmpty()) {
                // If an answer is selected, proceed
                if (selectedAnswer.equals(QuestionAnswer2.correctAnswers[currentQuestionIndex])) {
                    score++;
                }
                currentQuestionIndex++;
                loadNewQuestions();
                // Clear selected answer and disable submit button again
                selectedAnswer = "";
                submitBtn.setEnabled(false);
            } else {
                // Show a message to the user indicating they need to select an answer
                // You can use a Toast or any other suitable method
            }
        } else {
            // Reset the background color of all buttons
            resetButtonColors();

            // Set the background color of the selected button
            selectedAnswer = clickedButton.getText().toString();
            clickedButton.setBackgroundColor(Color.parseColor("#CBEAA6")); // Selected color

            // Enable the submit button
            submitBtn.setEnabled(true);
        }
    }

    void loadNewQuestions() {
        if (currentQuestionIndex >= totalQuestions) {
            finishQuiz();
            return;
        }

        // Reset the background color of all buttons when loading new questions
        resetButtonColors();

        questionsTextview.setText(QuestionAnswer2.question[currentQuestionIndex]);
        ansA.setText(QuestionAnswer2.choices[currentQuestionIndex][0]);
        ansB.setText(QuestionAnswer2.choices[currentQuestionIndex][1]);
        ansC.setText(QuestionAnswer2.choices[currentQuestionIndex][2]);
        ansD.setText(QuestionAnswer2.choices[currentQuestionIndex][3]);
        totalQuestionsTextview.setText("Total Questions: " + (totalQuestions - currentQuestionIndex));
    }

    void resetButtonColors() {
        ansA.setBackgroundColor(Color.parseColor("#FFC107")); // Unselected color
        ansB.setBackgroundColor(Color.parseColor("#FFC107")); // Unselected color
        ansC.setBackgroundColor(Color.parseColor("#FFC107")); // Unselected color
        ansD.setBackgroundColor(Color.parseColor("#FFC107")); // Unselected color
    }

    void finishQuiz() {
        String results = "";
        if (score > totalQuestions * 0.70) {
            results = "Congrats! You rocked";
        } else if (score > totalQuestions * 0.50) {
            results = "You did well";
        } else {
            results = "Try again to do better!";
        }
        new AlertDialog.Builder(this)
                .setTitle(results)
                .setMessage("Your score is " + score + " out of " + totalQuestions)
                .setPositiveButton("Restart", (dialogInterface, i) -> restartQuiz())
                .setPositiveButton("Back to Home", (dialogInterface, i) -> homeScreen())
                .show(); // Show the dialog
    }

    void restartQuiz() {
        score = 0;
        currentQuestionIndex = 0;
        loadNewQuestions();
    }

    void homeScreen() {
        Intent intent = new Intent(this, quizSelect.class);
        startActivity(intent);
        finish();
    }
}
