package com.example.myapplication1;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class quizSelect extends AppCompatActivity {
    private Button q1,q2,q3;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_select);

        q1 = findViewById(R.id.buttonq1);
        q2 = findViewById(R.id.buttonq2);
        q3 = findViewById(R.id.buttonq3);

        q1.setOnClickListener(v -> {
            Intent intent = new Intent(quizSelect.this, MainActivity.class);
            startActivity(intent);
        });
        q2.setOnClickListener(v -> {
            Intent intent = new Intent(quizSelect.this, Quiz2.class);
            startActivity(intent);
        });
        q3.setOnClickListener(v -> {
            Intent intent = new Intent(quizSelect.this, MainActivity.class);
            startActivity(intent);
        });
    }
}