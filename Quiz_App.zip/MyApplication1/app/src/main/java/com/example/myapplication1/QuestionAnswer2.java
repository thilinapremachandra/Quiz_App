package com.example.myapplication1;

public class QuestionAnswer2 {
    public static String question[] = {
            "Which programming language is primarily used for Android app development?",
            "What is the purpose of an Activity in Android development?",
            "Which XML attribute is used to specify the layout width of a view in Android?",
            "What is the name of the build system used by Android Studio?",
            "Which method is called when an Activity becomes visible to the user?",
            "Which lifecycle method is called when an Activity is first created?",
            "What is the purpose of an Intent in Android?",
            "Which Android component is used to display a scrollable list of items?",
            "What does the term 'Fragment' refer to in Android development?",
            "Which tool is used to debug and profile Android applications?"
    };
    public static String choices[][] = {
            {"Java", "Swift", "Kotlin", "Python"},
            {"To handle user interactions", "To manage the UI and handle user interaction", "To handle background tasks", "To store application data"},
            {"layout_width", "layout_height", "padding", "margin"},
            {"Maven", "Gradle", "Ant", "Ivy"},
            {"onCreate()", "onStart()", "onResume()", "onPause()"},
            {"onCreate()", "onStart()", "onResume()", "onDestroy()"},
            {"To perform background operations", "To display a toast message", "To navigate between different components", "To manage user preferences"},
            {"RecyclerView", "ListView", "ScrollView", "GridView"},
            {"A reusable UI component", "A background service", "A type of Activity", "A layout manager"},
            {"Eclipse", "NetBeans", "Android Studio", "ADB"}
    };
    public static String correctAnswers[] = {
            "Java",
            "To manage the UI and handle user interaction",
            "layout_width",
            "Gradle",
            "onStart()",
            "onCreate()",
            "To navigate between different components",
            "RecyclerView",
            "A reusable UI component",
            "ADB"
    };
}
